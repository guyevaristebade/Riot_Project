riot.compile().then(() => {
    riot.mount('timer')
})