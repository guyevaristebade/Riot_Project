riot.compile().then(() => {
    riot.mount('compte-personne')
})